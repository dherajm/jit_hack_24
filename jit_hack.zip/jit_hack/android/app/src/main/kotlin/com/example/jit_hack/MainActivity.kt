package com.example.jit_hack

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
